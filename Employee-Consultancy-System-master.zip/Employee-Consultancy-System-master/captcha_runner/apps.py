from django.apps import AppConfig


class CaptchaRunnerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'captcha_runner'
